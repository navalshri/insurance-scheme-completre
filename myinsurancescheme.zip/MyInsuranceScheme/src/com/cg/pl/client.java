package com.cg.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

import com.cg.eis.bean.Employee;
import com.cg.service.*;
import com.cg.service.Validator;

public class client {
  
	public static void main(String[] args) throws IOException 
	{
		EmployeeService service=new EmployeeService();
	
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        String choice="";
        while (true)
        {
        System.out.println("menu");
        System.out.println("==============");
        System.out.println("1. press 1 to enter the employee details");
        System.out.println("2. press 2 to get information about the insurance scheme");
        System.out.println("3. press 3 to exit the program");
        System.out.println("enter your choice");
        choice=br.readLine();
        switch (choice)
        {
        case "1":
        	int e_id=0;
        	double salary=0.00;
        	String name="";
        	String designation="";
        	System.out.println("enter employee id");
        	while(true)
        	{
        		String s_id=br.readLine();
        		boolean ch=Validator.Validatedata(s_id,Validator.idpattern);
        		if(ch==true)
        		{
        			try
        			{
        				e_id=Integer.parseInt(s_id);
        				break;
        			}
        			catch(NumberFormatException e)
        			{
        				System.out.println("employee id must be numeric");
        			}
        		}
        			else
        			{
        				System.out.println("employee id must be in 3 digits");
        			}
        		}
        	System.out.println("enter employee name");
        	while(true)
        	{
        		String s_name=br.readLine();
        		boolean ch1=Validator.Validatedata(s_name,Validator.namepattern);
        		if(ch1==true)
        		{
        			try
        			{
        				name=s_name;
        				break;
        			}
        			catch(NumberFormatException e)
        			{
        				System.out.println("employee name must be alphabetical");
        			}
        		}
        			else
        			{
        				System.out.println("employee name must be entered as first name and last name only and should be of atleast 3 alphabets");
        			}
        		}
        	
            System.out.println("enter salary");
        	while(true)
        	{
        		String s_salary=br.readLine();
        		boolean ch2=Validator.Validatedata(s_salary,Validator.salarypattern);
        		if(ch2==true)
        		{
        			try
        			{
        				salary=Double.parseDouble(s_salary);
        				break;
        			}
        			catch(NumberFormatException e)
        			{
        				System.out.println("salary must be numeric");
        			}
        		}
        			else
        			{
        				System.out.println("salary must be as per designation and positive");
        			}
        		}
        	System.out.println("Enter the designation of the employee");

			while (true) {
				String s_desig = br.readLine();
				boolean ch3 = Validator.ValidateDesignation(salary, s_desig);
				if (ch3 == true) {
					try {
						designation = s_desig;
						break;
					} catch (Exception e) {
						System.out.println("Designation is not correct");
						
					}
				} else
					System.out.println("Designation is  not correct as per salary. Please Re enter the designatio");
			}

			boolean ab= service.InsuranceScheme(e_id, name, salary, designation);
                        System.out.println(ab);
        			
        case "2":
        
        	
			System.out.println("enter id to get the information of insurance schemes");
			String s_id=br.readLine();
			e_id=Integer.parseInt(s_id);
			 Employee cd=service.getEmployeedetails(e_id);
			 System.out.println(cd);
        	break;
        
        	
    
        case "3":
        System.out.println("exiting program");
    	break;
        default:
    	 System.out.println("invalid choice");
        				}
        	}
        	
        
        
		
			
		
		}
	}


