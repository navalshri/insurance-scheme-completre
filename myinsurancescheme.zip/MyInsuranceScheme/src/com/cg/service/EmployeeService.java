package com.cg.service;

import com.cg.dao.EmployeeDAOImpl;
import com.cg.eis.bean.Employee;

public class EmployeeService 
{  
	EmployeeDAOImpl dao= new EmployeeDAOImpl();
	
public Employee getEmployeedetails(int ID)
{
	return dao.getEmployeedetails(ID);
	
}

public boolean InsuranceScheme(int id, String name, double salary, String designation)
{String insurance="";
	if((salary>5000 && salary <20000) && (designation.equalsIgnoreCase("system associate"))) 
	
		insurance="Scheme c";
	
	if((salary>=20000 && salary<40000) && designation.equalsIgnoreCase("programmer"))
	
		insurance="scheme b";

	if((salary>=40000) && designation.equalsIgnoreCase("Manager"))
		insurance="scheme a";

	if(salary<5000 && designation.equalsIgnoreCase("clerk"))
		insurance="no scheme";
Employee y= new Employee(id,name,salary,designation,insurance);

	
	return dao.addEmployeedetails(y);
	
}

}
