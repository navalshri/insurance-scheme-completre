package com.cg.service;

public interface Validator {
String idpattern="[1-9][0-9][0-9]";
String namepattern="([A-Za-z]{3}[A-Za-z]* [A-Za-z]{3}[A-Za-z]*)|([A-Za-z]{3}[A-Za-z]* [A-Za-z]{3}[A-Za-z]* [A-Za-z]{3}[A-Za-z]*)|([A-Za-z]+'[A-Za-z]*[A-Za-z]{3}[A-Za-z])";
String salarypattern="[1-9]{1}([0-9])*|[1-9]{1}([0-9])*.([0-9])*+";

public static boolean Validatedata(String data,String pattern)
{
	return data.matches(pattern);
}

public static boolean ValidateDesignation(double salary, String designation) 
{ 
	if((salary>5000 && salary <20000) && (designation.equalsIgnoreCase("system associate"))) return true;

if((salary>=20000 && salary<40000) && designation.equalsIgnoreCase("programmer"))
	return true;

if((salary>=40000) && designation.equalsIgnoreCase("Manager"))
	return true;

if(salary<5000 && designation.equalsIgnoreCase("clerk"))
	return true;

else
	return false;
}




}
