package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class EmployeeDAOImpl implements EmployeeDAO 
{
	Map<Integer,Employee> empMap=new HashMap<Integer,Employee>();
	public boolean addEmployeedetails(Employee y)
	{
		empMap.put(y.getE_id(),y);
		return true;
	
	}	
	

	@Override
	public Employee getEmployeedetails(int ID) 
	{
		Employee d=empMap.get(ID);
		
		return d;
	}




}
