package com.cg.dao;

import com.cg.eis.bean.Employee;

public interface EmployeeDAO 
{
	
public boolean addEmployeedetails(Employee y);
public Employee getEmployeedetails(int ID);
}
